# Changelog

### Funkcionalita

- aplikácia spľňa všetky implementačné požiadavky zadania
- žiadné ďalšie rozšírenia nad rámec zadanie pridané neboli

### Limitácie

- Žiadné limitácie známe nie su, až na limitácie programovacieho jazyka c++ (C++20) a použitých knižníc.
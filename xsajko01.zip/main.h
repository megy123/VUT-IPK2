/*
Project:    IPK 2. projekt
File:       main.h
Authors:    Dominik Sajko (xsajko01)
Date:       04.04.2024
*/

int main(int argc, char *argv[]);